package SauceDemo_TestNG;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Selenium_Project.Login_POM;
import junit.framework.Assert;

public class test001 {
	static WebDriver driver;
	@BeforeSuite
	public void open_the_browser()
	{
		driver=Selenium_Project.Operations.load_the_page();
	}
  @Test(priority = 1)
  public void validating_the_Title(){
	  System.out.println(driver.getTitle());
	  Assert.assertEquals("Swag Labs",driver.getTitle());
  }
  @Test(priority = 2)
  public void validating_the_URL(){
	  System.out.println(driver.getCurrentUrl());
	  Assert.assertEquals("https://www.saucedemo.com/",driver.getCurrentUrl());
  }
  @Test(priority = 3)
  public void read_the_credential() throws Exception{
	  ArrayList<String>credentials=Selenium_Project.excelReading_Values.read_the_values();
	  System.out.println(credentials);
//	  driver=Selenium_Project.Operations.entering_the_credentials(credentials.get(0),credentials.get(1));
	  Login_POM login=new Login_POM(driver);
	  login.enterUsername(credentials.get(0));
	  login.enterPassword(credentials.get(1));
	  login.clickButton();
	  driver=login.returndriver();
	  Assert.assertEquals("Products",driver.findElement(By.xpath("//*[@class='title']")).getText());
  }
//  @Test(priority = 4)
//  public void Validating_the_DropDown(){
//	   driver=Selenium_Project.Operations.validating_the_dropDown();
//	   
//  }
}
