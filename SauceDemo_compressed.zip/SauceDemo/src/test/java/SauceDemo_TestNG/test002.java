package SauceDemo_TestNG;

import org.testng.annotations.Test;

public class test002 {
  @Test
  public void f() {
  }
}
