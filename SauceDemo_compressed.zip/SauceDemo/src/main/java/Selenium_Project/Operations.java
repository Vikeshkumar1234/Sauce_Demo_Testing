package Selenium_Project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Operations {
  static WebDriver dr;
  public static WebDriver load_the_page()
  {
	  dr=new EdgeDriver();
	  dr.manage().window().maximize();
	  dr.get("https://www.saucedemo.com/");
	  return dr;
  }
}
